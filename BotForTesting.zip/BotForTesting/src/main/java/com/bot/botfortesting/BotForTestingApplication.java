package com.bot.botfortesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotForTestingApplication {

    public static void main(String[] args) {
        SpringApplication.run(BotForTestingApplication.class, args);
    }

}
