package com.bot.botfortesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotForTestingApplicationTests {

    @Test
    void contextLoads() {
    }

}
